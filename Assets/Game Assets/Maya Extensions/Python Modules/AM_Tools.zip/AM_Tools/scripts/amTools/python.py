"""
Utility functions for the Python language.

\b Creation \b Info:

\b Donations: http://adammechtley.com/donations/

\b License: The MIT License

Copyright (c) 2011 Adam Mechtley (http://adammechtley.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the 'Software'), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

\namespace amTools.python
"""

import sys

## the current version of Python
__version__ = float(sys.version[0:3])

def indexOf(obj, seq):
	"""Return the index of the first occurrence of obj in seq"""
	try:
		if __version__ < 2.6:
			for index in (i for i in xrange(len(seq)) if seq[i] == obj):
				return index
		else: return next((i for i in xrange(len(seq)) if seq[i] == obj), None)
	except: raise

def lastIndexOf(obj, seq):
	"""Return the index of the last occurrence of obj in seq"""
	try:
		if __version__ < 2.6:
			for index in (i for i in xrange(len(seq)-1, -1, -1) if seq[i] == obj):
				return index
		else: return next((i for i in xrange(len(seq)-1, -1, -1) if seq[i] == obj), None)
	except: raise