"""
A GUI to automatically create the twist structure for an upper arm.

\b Requirements:
AM_ShoulderConstraint.py

To use this tool, select one or more elbow joints and enter the desired data
into the option fields before pressing either the Create or Apply button.

To skin the model, the arm mesh should be skinned in segments for each twist
joint, plus one additional for the shoulder joint, where the segment at the
base of the shoulder is skinned to the first twist joint and the final segment
is skinned to the shoulder joint.

\par Setup Shoulder Options:
- \b Suffix \b of \b New \b Twist \b Joints:
Specifies the base naming suffix to apply to the newly created joints. Their
prefix will match the shoulder on which they are twisting and they will also be
numbered from 1 to n.
- \b Number \b of \b Twist \b Joints:
Specifies the number of twist joints to create for each shoulder. You must
create at least one and the first will always have the shoulder constraint
applied to it.
\par Shoulder Constraint Options:
- \b Spine \b Object:
Specifies the name of the object to use for computing the shoulder's elevation
angle. The shoulder constraint is designed with the expectation that this is
the terminal spine node that is the most direct parent of the shoulder joints
(i.e. the ribcage). Though this will produce perfectly valid values if any
intermediate joints exist (collar bone, scapula), such an intermediate joint
could be used instead, provided that the axes given for the spine node (below)
are transformed into the intermediate joint\'s local space.'
- \b Raised \b Angle \b Offset:
Specifies the amount that the first twist joint's up-vector constraint rotates
back when the shoulder is raised. A value between 0 and 90 is ideal and should
eliminate flipping in a normal human range of motion. The default value of 45
is recommended in most cases.'
- \b Shoulder \b Aim \b Axis:
Corresponds to the axis in the upper arm's local space that aims toward the
elbow joint.
- \b Shoulder \b Front \b Axis:
Corresponds to the axis in the upper arm's local space that points toward the
character's front.
- \b Spine \b Aim \b Axis:
Corresponds to the axis in the specified spine joint's local space that aims
toward the next vertebra (up).
- \b Spine \b Front \b Axis:
Corresponds to the axis in the specified spine joint's local space that aims
toward the character's front.

\b Creation \b Info:

\b Donations: http://adammechtley.com/donations/

\b License: The MIT License

Copyright (c) 2011 Adam Mechtley (http://adammechtley.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the 'Software'), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

\namespace amTools.rigging.shoulderSetup
"""

import sys
import maya.cmds as cmds
import amTools.utilities as utils
import amTools.utilities.ui as amui

# verify requirements
utils.plugins.verifyPlugin('AM_ShoulderConstraint', __file__)

## options window name
kSetupOptionsWindow = 'am_setupShoulderOptionsWindow'
## name of the tool
kToolName = 'Setup Shoulder'
## current version of the tool
kVersionNumber = '1.05'
## date of current version
kVersionDate = '2011.03.27'

def menuItem(*args):
	"""This function calls optionsWindow() from a menu item"""
	optionsWindow()

def optionsWindow():
	"""This function creates an options window for creating the shoulder twist
	structure. When executing it, select the elbows in the arms you are setting
	up, then press Create or Apply."""
	# create the main interface
	if cmds.window(kSetupOptionsWindow, q=True, ex=True):
		cmds.deleteUI(kSetupOptionsWindow)
	mainWindow = cmds.window(kSetupOptionsWindow, title='%s Options'%kToolName, menuBar=True, wh=(545,350))
	
	# build the menu bar
	cmds.menu(label='Help')
	amui.helpMenuItem(kToolName, __file__)
	amui.aboutMenuItem(kToolName, kVersionNumber, kVersionDate)
	
	mainForm = cmds.formLayout(nd=100)
	
	# build the section to get information about the new twist joints
	if_suffixName = cmds.textFieldGrp(text='_Twist', label='Suffix of New Twist Joints:')
	if_numberTwistJoints = cmds.intSliderGrp(v=3, min=1, max=10, fmn=1, fmx=100, label='Number of Twist Joints:', field=True)
	
	# position the input fields for the twist joints
	cmds.formLayout(mainForm, edit=True, attachForm=[(if_suffixName, 'left', 30), (if_suffixName, 'top', 5)], attachNone=[(if_suffixName, 'right'), (if_suffixName, 'bottom')])
	cmds.formLayout(mainForm, edit=True, attachForm=[(if_numberTwistJoints, 'left', 30)], attachNone=[(if_numberTwistJoints, 'right'), (if_numberTwistJoints, 'bottom')], attachControl=[(if_numberTwistJoints, 'top', 5, if_suffixName)])
	
	# build the section to get information for the shoulder constraint
	constraintFrame = eval('cmds.frameLayout(collapsable=True, label="Shoulder Constraint Options:" %s)'%(amui.__frameAlignCenter__))
	constraintForm = cmds.formLayout(nd=100)
	
	# attempt to guess what the spine is if there is a selection when the GUI is created
	spineText = 'CenterSpine'
	sel = cmds.ls(sl=True, l=True, type='transform')
	if sel and len(sel) > 0: # BUG: in Maya 8.5, a selection of length 0 returns None rather than an empty list
		try:
			shoulder = cmds.listRelatives(sel[0], p=True, f=True) # just use the first elbow in the selection
			collar = cmds.listRelatives(shoulder[0], p=True, f=True)
			spine = cmds.listRelatives(collar[0], p=True, f=True)
			spineText = spine[0]
		except: pass
		
	if_spine = cmds.textFieldGrp(label='Spine Object:', tx=spineText)
	if_raisedAngleOffset = cmds.floatSliderGrp(v=45, min=0, max=90, fmn=-180, fmx=180, label='Raised Angle Offset:', field=True)
	if_shoulderAimAxis = cmds.floatFieldGrp(v1=1, v2=0, v3=0, nf=3, pre=4, label='Shoulder Aim Axis:')
	if_shoulderFrontAxis = cmds.floatFieldGrp(v1=0, v2=0, v3=1, nf=3, pre=4, label='Shoulder Front Axis:')
	if_spineAimAxis = cmds.floatFieldGrp(v1=1, v2=0, v3=0, nf=3, pre=4, label='Spine Aim Axis:')
	if_spineFrontAxis = cmds.floatFieldGrp(v1=0, v2=0, v3=1, nf=3, pre=4, label='Spine Front Axis:')
	
	# position the input fields for the shoulder constraint
	cmds.formLayout(constraintForm, edit=True, attachForm=[(if_spine, 'left', 30), (if_spine, 'top', 5)], attachNone=[(if_spine, 'right'), (if_spine, 'bottom')])
	cmds.formLayout(constraintForm, edit=True, attachForm=[(if_raisedAngleOffset, 'left', 30)], attachNone=[(if_raisedAngleOffset, 'right'), (if_raisedAngleOffset, 'bottom')], attachControl=[(if_raisedAngleOffset, 'top', 5, if_spine)])
	cmds.formLayout(constraintForm, edit=True, attachForm=[(if_shoulderAimAxis, 'left', 30)], attachNone=[(if_shoulderAimAxis, 'right'), (if_shoulderAimAxis, 'bottom')], attachControl=[(if_shoulderAimAxis, 'top', 5, if_raisedAngleOffset)])
	cmds.formLayout(constraintForm, edit=True, attachForm=[(if_shoulderFrontAxis, 'left', 30)], attachNone=[(if_shoulderFrontAxis, 'right'), (if_shoulderFrontAxis, 'bottom')], attachControl=[(if_shoulderFrontAxis, 'top', 5, if_shoulderAimAxis)])
	cmds.formLayout(constraintForm, edit=True, attachForm=[(if_spineAimAxis, 'left', 30)], attachNone=[(if_spineAimAxis, 'right'), (if_spineAimAxis, 'bottom')], attachControl=[(if_spineAimAxis, 'top', 5, if_shoulderFrontAxis)])
	cmds.formLayout(constraintForm, edit=True, attachForm=[(if_spineFrontAxis, 'left', 30)], attachNone=[(if_spineFrontAxis, 'right'), (if_spineFrontAxis, 'bottom')], attachControl=[(if_spineFrontAxis, 'top', 5, if_spineAimAxis)])
	
	cmds.setParent('..') # go up to constraintForm
	cmds.setParent('..') # go up to mainForm
	
	# position the frame for the shoulder constraint
	cmds.formLayout(mainForm, edit=True, attachPosition=[(constraintFrame, 'left', -1, 0), (constraintFrame, 'right', -1, 100)], attachControl=[(constraintFrame, 'top', 5, if_numberTwistJoints)], attachNone=[(constraintFrame, 'bottom')])
	
	# create the buttons to execute the script
	cmd_create='amTools.rigging.shoulderSetup.doOptions ("%s", "%s", "%s", "%s", "%s", "%s", "%s", "%s")'%(
		if_suffixName, 
		if_numberTwistJoints, 
		if_spine, 
		if_raisedAngleOffset, 
		if_shoulderAimAxis, 
		if_shoulderFrontAxis, 
		if_spineAimAxis, 
		if_spineFrontAxis)
	utils.ui.threeButtonLayout(mainForm, mainWindow, cmd_create)
	
	cmds.showWindow(mainWindow)

def doOptions(input_suffix, input_numberTwistJoints, input_spine, input_raisedAngleOffset, input_shoulderAimAxis, input_shoulderFrontAxis, input_spineAimAxis, input_spineFrontAxis):
	"""This is the function called when the apply or create button is clicked"""
	try:
		# validate selection
		selection = utils.dg.validateSelection(type='transform', name='elbow joint objects', min=1)
		
		# validate suffix
		suffix = cmds.textFieldGrp(input_suffix, q=True, tx=True)
		utils.dg.validateAffix(suffix)
		
		# validate spine
		spine = cmds.textFieldGrp(input_spine, q=True, tx=True)
		utils.dg.verifyNode(spine)
		
		# set up the shoulder
		numberTwistJoints = cmds.intSliderGrp(input_numberTwistJoints, q=True, v=True)
		newSelection = []
		# perform setup for each elbow in the selection
		for elbow in selection:
			shoulder = cmds.listRelatives(elbow, p=True, f=True)
			shoulderShort = cmds.listRelatives(elbow, p=True)
			newJoints = doSetup(
				shoulderShort[0] + suffix, 
				numberTwistJoints, 
				elbow, 
				shoulder[0], 
				spine, 
				cmds.floatSliderGrp(input_raisedAngleOffset, q=True, v=True), 
				cmds.floatFieldGrp(input_shoulderAimAxis, q=True, v=True), 
				cmds.floatFieldGrp(input_shoulderFrontAxis, q=True, v=True), 
				cmds.floatFieldGrp(input_spineAimAxis, q=True, v=True), 
				cmds.floatFieldGrp(input_spineFrontAxis, q=True, v=True))
			newSelection += newJoints
		# select the newly created joints for easy editing
		cmds.select(newSelection)
	except: raise

def doSetup(baseName, numberTwistJoints, elbow, shoulder, spine, raisedAngleOffset, shoulderAimAxis, shoulderFrontAxis, spineAimAxis, spineFrontAxis):
	"""This function creates the new twist joints and returns a list of their names."""
	try:
		# validate baseName
		utils.dg.validateNodeName(baseName)
		
		# validate incoming object names
		utils.dg.verifyNode(elbow)
		utils.dg.verifyNode(shoulder)
		utils.dg.verifyNode(spine)
		
		# get the translation value for the elbow
		elbowTranslate = cmds.getAttr('%s.translate'%elbow)[0]
		
		# see if there is a side label
		bodySide = cmds.getAttr('%s.side'%shoulder)
		
		# find out what rotate order the shoulder is using
		rotateOrder = cmds.getAttr('%s.rotateOrder'%shoulder)
		
		# create the twist joints
		twistJoints = []
		
		for i in range(numberTwistJoints):
			cmds.select(cl=True)
			newJoint = cmds.joint(name='%s%s'%(baseName, i + 1))
			
			# set up the first joint
			if i == 0:
				newJoint = cmds.parent(newJoint, shoulder)[0]
				jointRadius = 1.0
				jointOrient = []
				if cmds.objectType(shoulder, isType='joint'):
					jointRadius = cmds.getAttr('%s.radius'%shoulder) * 0.5
				
				cmds.setAttr('%s.radius'%newJoint, jointRadius)
				cmds.setAttr('%s.jointOrient'%newJoint, 0,0,0)
				cmds.setAttr('%s.translate'%newJoint, 0,0,0)
				
				# create the shoulder constraint
				cmds.am_shoulderConstraint(
					newJoint,
					spineObject=spine,
					shoulderObject=shoulder,
					rao=raisedAngleOffset, 
					sha=shoulderAimAxis, 
					shf=shoulderFrontAxis, 
					spa=spineAimAxis, 
					spf=spineFrontAxis)
			# set up the rest of the joints
			else:
				newJoint = cmds.parent(newJoint, shoulder)[0]
				cmds.setAttr('%s.radius'%newJoint, jointRadius)
				cmds.setAttr('%s.jointOrient'%newJoint, 0,0,0)
				pct = float(i)/float(numberTwistJoints)
				cmds.setAttr('%s.translate'%newJoint, elbowTranslate[0]*pct, elbowTranslate[1]*pct, elbowTranslate[2]*pct)
				
				# create the orient constraint
				orientConstraint = cmds.orientConstraint([twistJoints[0], shoulder, newJoint])
				targetWeights = cmds.orientConstraint(q=True, weightAliasList=True)
				cmds.setAttr('%s.%s'%(orientConstraint[0], targetWeights[0]), numberTwistJoints - i)
				cmds.setAttr('%s.%s'%(orientConstraint[0], targetWeights[1]), i)
				cmds.setAttr('%s.interpType'%orientConstraint[0], 1)
				
			# set label and rotate order
			cmds.setAttr('%s.side'%newJoint, bodySide)
			cmds.setAttr('%s.type'%newJoint, 18)
			cmds.setAttr('%s.otherType'%newJoint, 'Shoulder Twist %s'%(i + 1), type='string')
			cmds.setAttr('%s.rotateOrder'%newJoint, rotateOrder)
			
			# add the new joint to the list to return
			twistJoints.append(newJoint)
			
		return twistJoints;
	except: raise