"""
Various functions to perform custom operations on models in a Maya scene when
Unity exports them to FBX.

\b Creation \b Info:

\b Donations: http://adammechtley.com/donations/

\b License: The MIT License

Copyright (c) 2011 Adam Mechtley (http://adammechtley.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the 'Software'), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

\namespace amTools.unity.models
"""

import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as om

def deleteNonDeformerHistory():
	"""Deletes non-deformer history on all meshes in the scene. This method is
	provided because FBX export occasionally will not properly export a model
	if it has non-deformer history."""
	meshes = cmds.ls(type='mesh')
	for mesh in meshes:
		try:
			cmds.select(mesh)
			mel.eval('doBakeNonDefHistory( 1, {"prePost" });')
		except:
			pass
	cmds.select(cl=True)

def triangulateAll():
	"""Triangulates all meshes in the scene and deletes non-deformer history.
	This method is provided since Maya's triangulation preserves mesh volume, 
	while Unity's is intended to optimally strip a mesh. In most cases, this
	function will reduce vertex count but also prevent a model from being
	optimized for stripping."""
	sel = om.MSelectionList()
	for x in cmds.ls(type='transform'): sel.add(x)
	models = []
	iter = om.MItSelectionList(sel)
	while not iter.isDone():
	    path = om.MDagPath()
	    iter.getDagPath(path)
	    objectName = path.fullPathName()
	    path.extendToShape()
	    fn = om.MFnDagNode(path)
	    if fn.typeName() == 'mesh':
	        models.append(objectName)
	    iter.next()
	for model in models: cmds.polyTriangulate(model)
	deleteNonDeformerHistory()