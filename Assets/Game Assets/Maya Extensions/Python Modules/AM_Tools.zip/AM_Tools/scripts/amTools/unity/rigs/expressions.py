"""
Add custom attributes to an object in the scene to describe the scene's
animation expressions as C# for the Unity APIs. These user properties are
stored in a way that they are to be parsed by Unity's AssetPostprocessor in
order to transport a rig into Unity for evaluation at run-time.

\b Requirements: Unity Pro with ImportMayaRigs.cs editor script and all its
dependencies.

\par Known Limitations:
	- All comments are stripped
	- The list of reserved keywords is not exhaustive
	- Only some node types are supported; see kSupportedReferenceTypes
	- Only basic math commands are supported on-demand inside of back-tics (see
	kMathCommandToUnity); all attribute values must be stored in variables
	first in order to work with math commands e.g.:
		$ty = object.translateY;
		$sqrtTy = `sqrt $ty`;
	- No syntax correction for bad ternary expressions such as e.g.:
		$foo=6.0+false?1.0:2.0; // this screws up in Maya anyway
	- No support for objects controlled by both an expression and an animation
	curve: e.g., pairBlend nodes connected to an expression
	- No support yet for changing Euler rotation order on the fly
	- BlendShape weights must have an alias (e.g., bs.target, not bs.weight[n])
	- Euler angles can be set to any value, but only decompose in the range
	[-180,180] in Unity; this process is not cheap, so consider instead using
	a more efficient alternative such as am_exposeTransform.angle to get angles
	- While jointOrient is supported, other pretransformations (as when
	freezing translation channels on a transform node) are not supported
	- No concerted effort has been made to ensure proper execution order of
	multiple expression nodes
	- No support for namespaces or references; your source model (which will
	have expressions on it in Unity) should not use them
	- No support yet for building code from a node network
	- No support yet for arrays and loops

\b Creation \b Info:

\b Donations: http://adammechtley.com/donations/

\b License: The MIT License

Copyright (c) 2011 Adam Mechtley (http://adammechtley.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the 'Software'), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

\namespace amTools.unity.rigs.expressions
"""

import math, re, sys, types
import amTools.python as ampy
import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as OM

def exportExpressions():
	"""Add user properties for the expression contents."""
	if len(cmds.ls(type='expression')) == 0: return
	
	# find the object in the scene to hold user properties
	attributeHolder = findAttributeHolder()
	# get all of the references linked up to expression nodes
	referenceList = findExpressionReferences()
	# get the (Unity) type for each reference
	refTypeDict = getReferenceDataTypeDict(referenceList)
	# get the conflict-resolved name for each reference
	conflictDict = getReferenceConflictDict(referenceList, refTypeDict)
	
	# add user properties for each reference field indicating the Maya node to which they link
	addReferenceFieldUserProperties(attributeHolder, conflictDict)
	# add a user property containing declarations for all reference fields
	addReferenceDeclarationUserProperties(attributeHolder, refTypeDict, conflictDict)
	# add user properties for each joint pretransformation quaternion
	jointOrientVars = addJointOrientDeclarationUserProperties(attributeHolder, refTypeDict, conflictDict)
	# add a user property for each MethodBody
	for expressionNode in cmds.ls(type='expression'):
		addMethodBodyUserProperty(attributeHolder, expressionNode, conflictDict, refTypeDict, jointOrientVars)

## a non-exhaustive list of reserved keywords to prevent variable and reference naming conflicts
kReservedKeywords = [
	u'bool', u'float', u'int', u'string', u'short', u'long', u'double', u'char'
	u'Quaternion', u'Transform', u'Vector2', u'Vector3', u'Vector4',
	u'UnityEngine', u'UnityEditor', u'System', u'Mathf', u'Debug',
	u'CharacterController', u'Collider', u'BoxCollider', u'CapsuleCollider', u'SphereCollider', u'Rigidbody',
	u'FloatMatrix', u'QuaternionHelpers', u'VectorHelpers', u'EulerRotationOrder',
	u'BlendShape',
	u'MayaNode',
	u'AimConstraint', u'OrientConstraint', u'PointConstraint',
	u'ExposeTransform', u'ShoulderConstraint', u'HipConstraint',
	u'useGUILayout', u'enabled', u'transform', u'rigidbody', u'camera', u'light', u'animation', u'constantForce', u'renderer', u'audio', u'guiText', u'networkView', u'guiTexture', u'collider', u'hingeJoint', u'particleEmitter', u'gameObject', u'tag', u'name', u'hideFlags',
	u'importScale', u'oneOverImportScale', u'isInvokedExternally', u'upstreamDependencies', u'localPosition', u'localEulerAngles', u'localScale']

## a list of reference types that are supported in expressions
kSupportedReferenceTypes = [
	u'BlendShape',
	u'ExposeTransform',
	u'AimConstraint',
	u'OrientConstraint',
	u'PointConstraint',
	u'Transform']

## a list of MEL variable types that are supported
kSupportedVariableTypes = [u'float', u'int', u'string']

def findAttributeHolder():
	"""Return an object in the scene to hold user properties"""
	# if there are any skinned meshes, then a joint should be a candidate
	holders = []
	if (len(cmds.ls(type='skinCluster')) > 0): holders = cmds.ls(type='joint')
	# otherwise a locator is a good candidate
	else: holders = cmds.ls(type='locator')
	# if no candidates have been found
	if (len(holders) == 0):
		holders = cmds.ls(type='mesh')
		if (len(holders) == 0): return # nothing valid to add the expression properties to
		sel = OM.MSelectionList()
		sel.add(holders[0])
		dagPath = OM.MDagPath()
		sel.getDagPath(0, dagPath)
		dagPath.pop(1)
		holders = [dagPath.partialPathName()]
	# simply select the first possible candidate
	return holders[0]

def findExpressionReferences():
	"""Find all references connected to expression nodes"""
	referenceList = []
	expressions = cmds.ls(type='expression')
	for expression in expressions:
		connectedNodes = cmds.listConnections(expression, skipConversionNodes=True)
		for node in connectedNodes:
			if not node in referenceList: referenceList.append(node)
	return referenceList

def getReferenceDataTypeDict(referenceList):
	"""Return a dictionary whose keys are extant reference names and values are data types
	@param referenceList a list of all objects connected to expression nodes"""
	referenceDict = {}
	for reference in referenceList:
		referenceType = cmds.nodeType(reference)
		if referenceType.find('am_') == 0: referenceType = referenceType[3:] # strip am_ prefix
		referenceType = '%s%s'%(referenceType[0].upper(), referenceType[1:])
		if referenceType == 'Joint': referenceType = 'Transform'
		if referenceType in kSupportedReferenceTypes: referenceDict[reference] = referenceType
	return referenceDict

def getReferenceConflictDict(referenceList, refTypeDict):
	"""Return a dictionary whose keys are extant reference names and values are conflict-resolved names
	@param referenceList a list of all objects connected to expression nodes
	@param refTypeDict a dictionary storing the Unity type for each reference in the list"""
	conflictDict = {}
	for reference in referenceList:
		if not reference in refTypeDict: continue
		if (not reference in kReservedKeywords): conflictDict[reference] = reference
		else: conflictDict[reference] = '__refNameConflict__%s'%reference
	return conflictDict

def addReferenceFieldUserProperties(attributeHolder, conflictDict):
	"""Add user properties for each of the references
	@param attributeHolder the object in the scene that will store all custom attributes for expressions
	@param conflictDict a dictionary mapping Maya reference names to conflict-resolved alternatives"""
	extantAttrs = cmds.listAttr(attributeHolder)
	for conflict in conflictDict:
		newAttrName = 'expression__field__%s'%conflictDict[conflict]
		if not newAttrName in extantAttrs: cmds.addAttr(attributeHolder, ln=newAttrName, dt='string')
		if not cmds.nodeType(conflict) == 'blendShape':
			cmds.setAttr('%s.%s'%(attributeHolder,newAttrName), conflict, type='string')
		else: # a bit dirty for now, but it will do
			modelWithBlendShape = ''
			# find all of the potential models in the scene
			models = OM.MSelectionList()
			for model in cmds.ls(transforms=True): models.add(model)
			dagPath = OM.MDagPath()
			# search for a blendShape connection
			iter = OM.MItSelectionList(models)
			while not iter.isDone():
				iter.getDagPath(dagPath)
				model = OM.MDagPath(dagPath)
				# ensure the current transform has a shape node
				try: dagPath.extendToShape()
				except: iter.next()
				# search upstream from shape for all blendShape nodes
				try:
					dg = OM.MItDependencyGraph(dagPath.node(), OM.MFn.kBlendShape, OM.MItDependencyGraph.kUpstream)
					while not dg.isDone():
						# add the blendShape nodes to a list in the dictionary
						fn = OM.MFnDependencyNode(dg.currentItem())
						if fn.name() == conflict: modelWithBlendShape = model.partialPathName()
						dg.next()
				except: pass
				iter.next()
			cmds.setAttr('%s.%s'%(attributeHolder,newAttrName), modelWithBlendShape, type='string')

def addReferenceDeclarationUserProperties(attributeHolder, refTypeDict, conflictDict):
	"""Add user properties for each reference field declaration
	@param attributeHolder the object in the scene that will store all custom attributes for expressions
	@param refTypeDict a dictionary storing the Unity type for each reference in the list
	@param conflictDict a dictionary mapping Maya reference names to conflict-resolved alternatives"""
	for i in xrange(len(conflictDict)):
		newAttrName = 'expression__declaration__%s'%i
		if not newAttrName in cmds.listAttr(attributeHolder): cmds.addAttr(attributeHolder, ln=newAttrName, dt='string')
		var = conflictDict.items()[i][0]
		cmds.setAttr('%s.%s'%(attributeHolder,newAttrName), 'public %s %s;'%(refTypeDict[var], conflictDict[var]), type='string')

def addJointOrientDeclarationUserProperties(attributeHolder, refTypeDict, conflictDict):
	"""Add user properties for each jointOrient variable declaration, and return a dictionary mapping each joint to its prerotation variable
	@param attributeHolder the object in the scene that will store all custom attributes for expressions
	@param refTypeDict a dictionary storing the Unity type for each reference in the list
	@param conflictDict a dictionary mapping Maya reference names to conflict-resolved alternatives"""
	joints = []
	for e in cmds.ls(type='expression'):
		for j in cmds.listConnections(e, scn=True):
			if not j in joints and cmds.nodeType(j) == 'joint':
				joints.append(j)
	preRotations = {}
	numDeclarations = len(refTypeDict) # how many existing declaration attribute are there?
	for i in xrange(len(joints)):
		# jointOrient attribute is stored as an XYZ Euler rotation
		jointOrient = cmds.getAttr('%s.jointOrient'%joints[i])[0]
		euler = OM.MEulerRotation(math.radians(jointOrient[0]), math.radians(jointOrient[1]), math.radians(jointOrient[2]), OM.MEulerRotation.kXYZ)
		q = OM.MQuaternion(euler.asQuaternion())
		varName = ''
		if joints[i] in conflictDict: varName = conflictDict[joints[i]]
		else: varName = joints[i]
		varName += '_jointOrient'
		preRotations[joints[i]] = varName
		newAttrName = 'expression__declaration__%s'%(i+numDeclarations)
		if not newAttrName in cmds.listAttr(attributeHolder): cmds.addAttr(attributeHolder, ln=newAttrName, dt='string')
		cmds.setAttr('%s.%s'%(attributeHolder,newAttrName), 'private Quaternion %s = new Quaternion(%sf,%sf,%sf,%sf);'%(varName,q.x,-q.y,-q.z,q.w), type='string')
	return preRotations

def addMethodBodyUserProperty(attributeHolder, expressionNode, conflictDict, refTypeDict, jointOrientVars):
	"""Add a user property for each method body
	@param attributeHolder the object in the scene that will store all custom attributes for expressions
	@param expressionNode the expression node to translate into C#
	@param conflictDict a dictionary mapping Maya reference names to conflict-resolved alternatives
	@param refTypeDict a dictionary storing the Unity type for each reference in the list
	@param jointOrientVars a dictionary mapping joint names to their prerotation Quaternion variables"""
	newAttrName = 'expression__methodBody__%s%s'%(expressionNode[0].upper(), expressionNode[1:])
	if not newAttrName in cmds.listAttr(attributeHolder): cmds.addAttr(attributeHolder, ln=newAttrName, dt='string')
	try: cmds.setAttr('%s.%s'%(attributeHolder, newAttrName), expressionAsCSharpFunction(expressionNode, conflictDict, refTypeDict, jointOrientVars), type='string')
	except: pass

def expressionAsCSharpFunction(expressionNode, conflictDict, refTypeDict, jointOrientVars):
	"""Return the expression node's contents as C# for Unity
	@param expressionNode the expression node to translate into C#
	@param conflictDict a dictionary mapping Maya reference names to conflict-resolved alternatives
	@param refTypeDict a dictionary storing the Unity type for each reference in the list
	@param jointOrientVars a dictionary mapping joint names to their prerotation Quaternion variables"""
	# get the expression's contents
	expression = cmds.expression(expressionNode, q=True, s=True)
		
	# remove comments
	expression = re.sub('//.*?[\n\r]', '', expression)
	for comment in re.findall('/\*.*?\*/', expression, re.DOTALL):
		expression = expression.replace(comment, '')
	
	# find types of reference fields and variables
	referenceFieldDict = getReferenceFieldDict(expressionNode)
	variableTypeDict = getVariableTypeDict(expression, referenceFieldDict)
	
	# append variable name conflicts to conflictDict
	for v in variableTypeDict:
		if not v[1:] in kReservedKeywords and not v[1:] in conflictDict: conflictDict[v] = v
		else: conflictDict[v] = '$__varNameConflict__%s'%v[1:]
	
	# fix naming conflicts
	for conflict in conflictDict:
		if re.match('%s(?=\W)'%re.escape(conflict), expression):
			expression = re.sub('\A%s(?=\W)'%re.escape(conflict), conflictDict[conflict], expression, 1)
		expression = re.sub('(?<=\W)%s(?=\W)'%re.escape(conflict), conflictDict[conflict], expression)
	
	# attempt to make on-demand math commands Unity-friendly
	expression = convertMathCommands(expression)
	
	# make print statements Unity-friendly
	skip = 0
	while len(re.findall('print\s+.*?;', expression)) > skip:
		printStatement = list(re.finditer('print\s+.*?;', expression))[skip]
		if printStatement.start(0) == 0 or not re.match('[\w\d.$]', expression[printStatement.start(0)-1]):
			expression = (expression[0:printStatement.start(0)] + 
				'Debug.Log(%s);'%re.match('.*?(?=;)', printStatement.group(0)[len('print'):].lstrip()).group(0) + 
				expression[printStatement.end(0):])
		else: skip += 1
	
	# reformat lines so there is one line of code per line of text
	lines = expression.split(';')
	expression = ''
	for line in lines:
		if line == '': continue
		if line[-1] == '}': line = '\n%s'%re.sub('\n', ' ', line.lstrip().rstrip())
		else: line = '\n%s;'%re.sub('\n', ' ', line.lstrip().rstrip())
		expression += re.sub('  ', ' ', line)
	expression = re.sub(';\n}', '; }\n', expression.lstrip())
		
	# remove lines that have only a declaration
	lines = expression.split(';')
	expression = ''
	for line in lines:
		if line == '': continue
		if re.search('\w+\s+\$\w+', line):
			if not '=' in line: continue
			else: line = re.sub('\w+\s+(?=\$\w)', '', line)
		if line[-1] == '}' or line[-1] == '\n': expression += line
		else: expression += '%s;'%line
	
	# split multi-assignments into separate lines
	lines = expression.split(';')
	for line in lines:
		newLines = ['%s;'%line]
		assignments = re.split('(?<![=<>])=(?!=)', line)
		finalValue = assignments[len(assignments)-1]
		if len(assignments) > 2:
			newLines = []
			for i in range(len(assignments)-1):
				if i == 0: newLines.append('%s = %s;'%(assignments[i].rstrip(), finalValue.lstrip()))
				else: newLines.append('%s = %s;'%(assignments[i].rstrip(), re.match('[\s\w.]+', assignments[0][::-1]).group(0)[::-1].rstrip().lstrip()))
		replacementLine = newLines[0]
		for i in range(len(newLines)):
			if i == 0: continue
			replacementLine = '%s\n%s'%(replacementLine, newLines[i])
		expression = expression.replace('%s;'%line, replacementLine)
	
	# reformat operators
	for op in ['=', '==', '<', '<=', '>', '>=', '!=', '+', '+=', '-=', '*', '*=', '/', '/=', '?', ':']:
		expression = re.sub('(?<=[\w\d\s()])%s(?=[\w\d\s()$])'%re.escape(op), ' %s '%op, expression)
		expression = re.sub('(?<=[\w\d()])\s+%s\s+(?=[\w\d()$])'%re.escape(op), ' %s '%op, expression)
	for op in ['-']:
		expression = re.sub('\s+%s\s+'%re.escape(op), op, expression)
		expression = re.sub('(?<=[\w\d()])%s(?=[\w\d()$])'%re.escape(op), ' %s '%op, expression)
		expression = re.sub('(?<=[\w\d()])%s%s(?=[\w\d()$])'%(re.escape(op),re.escape(op)), '%s %s'%(op,op), expression)
		expression = re.sub('(?<=[\w\d)])%s\s'%(re.escape(op)), ' %s '%op, expression)
	for op in ['++', '--']: # TODO: this hasn't been thoroughly examined
		expression = re.sub('\s+%s'%re.escape(op), '%s'%op, expression)
	
	# reformat one-line if-statements
	lines = expression.split('\n')
	expression = ''
	for line in lines:
		line = line.lstrip().rstrip()
		if (re.match('if\W', line) or re.match('else if\W', line)) and not re.search('{', line):
			openCt = 0
			closeCt = 0
			endBlock = 0
			for i in xrange(len(line)):
				if endBlock > 0: continue
				if line[i] == '(': openCt += 1
				elif line[i] == ')':
					closeCt += 1
					if openCt > 0 and openCt == closeCt: endBlock = i
			if endBlock > 0: line = '%s\n{%s;}'%(line[:endBlock+1], line[endBlock+1:-1])
		elif re.match('else\W', line) and not re.search('{', line):
			line = 'else {%s}'%line[5:]
		expression += '%s\n'%line
	
	# reformat tabbing
	expression = re.sub('{', '\n{\n', expression)
	expression = re.sub('}', '\n}\n', expression)
	lines = expression.split('\n')
	expression = ''
	indent = 0
	for line in lines:
		line = line.lstrip().rstrip()
		line = re.sub('\s+', ' ', line)
		if line == '': continue
		bracketOpen = len(re.findall('{', line))
		bracketClose = len(re.findall('}', line))
		if bracketOpen<bracketClose: indent -= 1
		expression += '%s%s\n'%('\t'*indent, line)
		if bracketOpen>bracketClose: indent += 1
	expression = expression.rstrip()
	
	# consolidate literal blocks
	expression = consolidateLiteralBlocks(expression, conflictDict, referenceFieldDict, variableTypeDict)
	
	# correct assignments
	expression = correctAssignments(expression, conflictDict, refTypeDict, referenceFieldDict, variableTypeDict, jointOrientVars)
	
	# replace attributeNames with names of Unity fields as needed
	expression = correctReferenceFieldSyntax(expression, conflictDict, refTypeDict)
	
	# clean up spacing
	for op in ['= =', '< =', '> =', '! =', '+ =', '- =', '* =', '/ =']:
		expression = re.sub(re.escape(op), op.replace(' ', ''), expression)
	matches = list(re.finditer('(?<=\()\-\s(?=\d)', expression))
	for match in matches: expression = re.sub(re.escape(match.group(0)), '-', expression)
	
	# convert addition and subtraction of negatives
	expression = re.sub('\+\s\-(?=\S)', '- ', expression)
	expression = re.sub('\+\s\(\-\(', '- ((', expression)
	expression = re.sub('\-\s\-(?=\S)', '+ ', expression)
	expression = re.sub('\-\s\(\-\(', '+ ((', expression)
	
	# correct float literal syntax
	expression = correctFloatLiteralSyntax(expression)
	
	# comment out lines with broken references e.g., .I[1] or .O[3]
	lines = expression.split('\n')
	expression = ''
	for line in lines:
		if line == '': continue
		if re.search('\s\.\w', line) or re.match('\.\w', line): line = '//%s // ERROR: Missing object reference. Check your Maya file.'%line
		expression += '%s\n'%line
	expression = expression.rstrip()
	
	# put all variable declarations up front
	declarations = ''
	for var in variableTypeDict:
		declarations += '\n%s %s;'%(variableTypeDict[var], conflictDict[var])
	expression = (declarations.lstrip()+'\n\n'+expression.lstrip()).lstrip()
	
	# remove variable symbols
	expression = expression.replace('$', '')
	
	#print expression
	return expression

def getReferenceFieldDict(expressionNode):
	"""Collect all references and get their types
	@param expressionNode the expression node to translate into C#"""
	connectedPlugs = cmds.listConnections(expressionNode, scn=True, plugs=True)
	referenceFields = {} # plugName : type
	for plug in connectedPlugs:
		referenceFields[plug] = cmds.getAttr(plug, type=True)
		if u'double' in referenceFields[plug]: referenceFields[plug] = u'float'
		if u'enum' in referenceFields[plug]: referenceFields[plug] = u'int'
		if u'bool' in referenceFields[plug]: referenceFields[plug] = u'int'
	return referenceFields

def getVariableTypeDict(expression, referenceFieldDict):
	"""Collect all variable types and their types into a dictionary of varName:varType pairs
	@param expression the contents of the expression node at this point in the translation process
	@param referenceFieldDict a dictionary mapping Maya attributes names to C# field types"""
	lines = expression.split(';')
	variableTypes = {}
	for line in lines:
		variables = re.findall('\$\w+', line)
		for var in variables:
			# see if the type is explicitly given
			declaration = re.search('\w+\s+\%s'%var, line) # backslash is needed since variable name starts with $
			if declaration and re.split('\s+', declaration.group(0))[0] in kSupportedVariableTypes:
				variableTypes[var] = re.split('\s+', declaration.group(0))[0]
			if var in variableTypes: continue
			
			# try to determine type on the basis of assignment value
			assignments = re.findall('.*\%s.*=(?!=).*'%var, line) # backslash is needed since variable name starts with $
			for assignment in assignments:
				# obtain the type of the last term on the line
				terms = re.split('\W+', assignment)
				lastTerm = terms[-1]
				if assignment[assignment.rfind(lastTerm)-1] == '.': # lastTerm is a member of a reference or a decimal
					lastTerm = '%s.%s'%(terms[-3],lastTerm)
				
				# set the type based on the last term
				if (assignment[assignment.rfind(lastTerm)+len(lastTerm)-1] == '"'): variableTypes[var] = 'string' # a string literal
				elif lastTerm == 'true' or lastTerm == 'false': variableTypes[var] = 'int' # an int literal
				elif lastTerm in referenceFieldDict: variableTypes[var] = referenceFieldDict[lastTerm] # a reference with a known type
				elif '.' in lastTerm: variableTypes[var] = 'float' # a decimal literal
				# an integer literal is ambiguous and requires extra work
				else:
					if var in variableTypes and variableTypes[var] == 'float': continue
					# initially presume an int since it can be cast as a decimal
					variableTypes[var] = 'int'
					# var is a float if the assignment value contains a float literal or a variable or reference known to be a float
					# get the assignment value
					val = re.search('(?<==)(?!=).*', assignment).group(0).lstrip()
					# first strip comparisons from ternaries
					if ':' in val:
						terms = val.split('?')
						for i in range(len(terms)):
							if i == len(terms)-1: continue
							comparison = terms[i][terms[i].index('('):terms[i].rindex(')')+1]
							while (not comparison.index(')') == len(comparison)-1 and comparison[0:comparison.index(')')].count('(') == 1):
								comparison = comparison[comparison.index(')'):]
								comparison = comparison[comparison.index('('):]
							val = val.replace(comparison, '')
					# check remaining terms against known float variables
					for v in variableTypes:
						if re.search('%s(?=\W)'%v, val) and variableTypes[v] == 'float': variableTypes[var] = 'float'
					# check remaining terms against known float references
					for ref in referenceFieldDict:
						if re.search('%s(?=\W)'%ref, val) and referenceFieldDict[ref] == 'float': variableTypes[var] = 'float'
					if var in variableTypes and variableTypes[var] == 'float': continue
					# check if there is a math command in backticks
					for mc in kMathCommandRegExps:
						if re.search('`%s'%mc, val): variableTypes[var] = 'float'
					# check remaining terms for a float literal
					if '.' in val:
						variableTypes[var] = 'float'
						possibilities = re.findall('\w+\.\w+', val)
						for p in possibilities:
							if not p.split('.')[0].isnumeric() or not p.split('.')[1].isnumeric(): variableTypes[var] = 'int'
	return variableTypes

## a search pattern for a command argument
kCmdArgRE = '\s+[$\w\d.]+'

## a dictionary to match a regular expression to a particular command
kMathCommandRegExps = {
	'abs%s'%kCmdArgRE:'abs',
	'ceil%s'%kCmdArgRE:'ceil',
	'clamp%s%s%s'%(kCmdArgRE,kCmdArgRE,kCmdArgRE):'clamp',
	'cos%s'%kCmdArgRE:'cos', 'acos%s'%kCmdArgRE:'acos', 'cosd%s'%kCmdArgRE:'cosd', 'acosd%s'%kCmdArgRE:'acosd',
	'deg_to_rad%s'%kCmdArgRE:'deg_to_rad',
	'equivalent%s%s'%(kCmdArgRE,kCmdArgRE):'equivalent',
	'equivalentTol%s%s%s'%(kCmdArgRE,kCmdArgRE,kCmdArgRE):'equivalentTol',
	'exp%s'%kCmdArgRE:'exp',
	'floor%s'%kCmdArgRE:'floor',
	'hypot%s%s'%(kCmdArgRE,kCmdArgRE):'hypot',
	'linstep%s%s%s'%(kCmdArgRE,kCmdArgRE,kCmdArgRE):'linstep',
	'log%s'%kCmdArgRE:'log',
	'log1p%s'%kCmdArgRE:'log1p',
	'log10%s'%kCmdArgRE:'log10',
	'max%s%s'%(kCmdArgRE,kCmdArgRE):'max',
	'min%s%s'%(kCmdArgRE,kCmdArgRE):'min',
	'pow%s%s'%(kCmdArgRE,kCmdArgRE):'pow',
	'rad_to_deg%s'%kCmdArgRE:'rad_to_deg',
	'rand%s%s'%(kCmdArgRE,kCmdArgRE):'rand',
	'sign%s'%kCmdArgRE:'sign',
	'sin%s'%kCmdArgRE:'sin', 'asin%s'%kCmdArgRE:'asin', 'sind%s'%kCmdArgRE:'sind', 'asind%s'%kCmdArgRE:'asind',
	'smoothstep%s%s%s'%(kCmdArgRE,kCmdArgRE,kCmdArgRE):'smoothstep',
	'sqrt%s'%kCmdArgRE:'sqrt',
	'tan%s'%kCmdArgRE:'tan', 'atan2%s'%kCmdArgRE:'atan2', 'tand%s'%kCmdArgRE:'tand', 'atand%s'%kCmdArgRE:'atand', 'atan2d%s'%kCmdArgRE:'atan2d',
	'trunc%s'%kCmdArgRE:'trunc'
	}

## a dictionary to map a supported on-demand command to a Unity API method
kMathCommandToUnity = {
	'abs':'Mathf.Abs(%s)',
	'ceil':'Mathf.Ceil(%s)',
	'clamp':'Mathf.Clamp(%s, %s, %s)',
	'cos':'Mathf.Cos(%s)', 'acos':'Mathf.Acos(%s)', 'cosd':'Mathf.Cos(Mathf.Deg2Rad*%s)', 'acosd':'Mathf.Rad2Deg*Mathf.Acos(%s)',
	'deg_to_rad':'Mathf.Deg2Rad*%s',
	'equivalent':'Mathf.Approximately(%s, %s)',
	'equivalentTol':'(%s-%s < %s)',
	'exp':'Mathf.Exp(%s)',
	'floor':'Mathf.Floor(%s)',
	'hypot':'new Vector2(%s,%s).magnitude',
	'linstep':'Mathf.Lerp(%s,%s,%s/(%s-%s))',
	'log':'Mathf.Log(%s)',
	'log1p':'Mathf.Log(1f+%s)',
	'log10':'Mathf.Log10(%s)',
	'max':'Mathf.Max(%s,%s)',
	'min':'Mathf.Min(%s,%s)',
	'pow':'Mathf.Pow(%s,%s)',
	'rad_to_deg':'Mathf.Rad2Deg*%s',
	'rand':'Random.Range(%s,%s)',
	'sign':'Mathf.Sign(%s)',
	'sin':'Mathf.Sin(%s)', 'asin':'Mathf.Asin(%s)', 'sind':'Mathf.Sin(Mathf.Deg2Rad*%s)', 'asind':'Mathf.Rad2Deg*Mathf.Asin(%s)',
	'smoothstep':'Mathf.SmoothStep(%s,%s,%s/(%s-%s))',
	'sqrt':'Mathf.Sqrt(%s)',
	'tan':'Mathf.Tan(%s)', 'atan2':'Mathf.Atan2(%s)', 'tand':'Mathf.Tan(Mathf.Deg2Rad*%s)', 'atand':'Mathf.Rad2Deg*Mathf.Atan(%s)', 'atan2d':'Mathf.Rad2Deg*Mathf.Atan2(%s)',
	'trunc':'(float)((int)(%s))'
	}

## a dictionary to reorder arguments in a command for the corresponding Unity API method
kMathCommandArgOrder = {
	'abs':[0],
	'ceil':[0],
	'clamp':[2,0,1], # clamp min max value : Mathf.Clamp(value, min, max)
	'cos':[0], 'acos':[0], 'cosd':[0], 'acosd':[0],
	'deg_to_rad':[0],
	'equivalent':[0,1],
	'equivalentTol':[0,1,2],
	'exp':[0],
	'floor':[0],
	'hypot':[0,1],
	'linstep':[0,1,2,1,0],  # linstep min max val : Mathf.Lerp(min, max, val/(max-min)) 
	'log':[0],
	'log1p':[0],
	'log10':[0],
	'max':[0,1],
	'min':[0,1],
	'pow':[0,1],
	'rad_to_deg':[0],
	'rand':[0,1],
	'sign':[0],
	'sin':[0], 'asin':[0], 'sind':[0], 'asind':[0],
	'smoothstep':[0,1,2,1,0], # smoothstep min max val : Mathf.SmoothStep(min, max, val/(max-min))
	'sqrt':[0],
	'tan':[0], 'atan':[0], 'atan2':[0], 'tand':[0], 'atand':[0], 'atan2d':[0],
	'trunc':[0]
	}

def convertMathCommands(expression):
	"""Convert on-demand math commands inside of backticks into corresponding Unity API calls
	@param expression the contents of the expression node at this point in the translation process"""
	for regexp in kMathCommandRegExps:
		command = kMathCommandRegExps[regexp]
		while len(re.findall('`.*?%s.*?`'%regexp, expression)) > 0:
			block = re.search('`.*?%s.*?`'%regexp, expression)
			args = re.split('\s+', block.group(0))[1:]
			evaluateIt = True
			for arg in args:
				if '$' in arg: evaluateIt = False
			# if the arguments are all literals, then simply evaluate the result
			if evaluateIt:
				expression = re.sub(re.escape(block.group(0)), '%s'%mel.eval(block.group(0)[1:-1]), expression)
			# otherwise substitute in syntax for the appropriate Unity method
			else:
				substitute = kMathCommandToUnity[command]
				for i in xrange(len(kMathCommandArgOrder[command])):
					substitute = re.sub('%s', args[kMathCommandArgOrder[command][i]], substitute, 1)
				substitute = re.sub('`', '', substitute)
				expression = re.sub(re.escape(block.group(0)), substitute, expression)

	return expression

## a dictionary to map Maya attributes to corresponding fields on Unity Transform objects
kTransformAttributeAsUnityMember = {
	u'translateX':u'localPosition.x',
	u'translateY':u'localPosition.y',
	u'translateZ':u'localPosition.z',
	u'rotateX':u'localEulerAngles.x',
	u'rotateY':u'localEulerAngles.y',
	u'rotateZ':u'localEulerAngles.z',
	u'scaleX':u'localScale.x',
	u'scaleY':u'localScale.y',
	u'scaleZ':u'localScale.z'
	}

## a dictionary to map Maya attributes to corresponding fields on Unity ExposeTransform objects
kExposeTransformAttributeAsUnityMember = {
	u'eulerOutputRotateOrder' : u'rotateOrder',
	u'rotateOrder' : u'rotateOrder',
	u'nomalizeAxes': u'nomalizeAxes',
	u'nomalize': u'nomalizeAxes',
	u'objectAxis': u'objectAxis',
	u'axis': u'objectAxis',
	u'referenceAxis': u'referenceAxis',
	u'refAxis': u'referenceAxis',
	u'position0': u'position.x',
	u'position1': u'position.y',
	u'position2': u'position.z',
	u'distance': u'distance',
	u'eulerRotation0': u'rotation.x',
	u'eulerRotation1': u'rotation.y',
	u'eulerRotation2': u'rotation.z',
	u'dotProduct': u'dot',
	u'dot': u'dot',
	u'angle': u'angle',
	u'dotToTarget': u'dotToTarget',
	u'dotTo': u'dotToTarget',
	u'angleToTarget': u'angleToTarget',
	u'angleTo': u'angleToTarget'
	}

## a dictionary to map Maya attributes to corresponding fields on Unity MayaConstraint objects
kConstraintAttributeAsUnityMember = {
	u'offsetX':u'offset.x',
	u'offsetY':u'offset.y',
	u'offsetZ':u'offset.z'
	}

## a dictionary mapping reference type to its attribute dictionary
kAttributeDictionaries = {
	'ExposeTransform':kExposeTransformAttributeAsUnityMember,
	'AimConstraint':kConstraintAttributeAsUnityMember,
	'OrientConstraint':kConstraintAttributeAsUnityMember,
	'PointConstraint':kConstraintAttributeAsUnityMember,
	'Transform':kTransformAttributeAsUnityMember
	}

## a dictionary of possible rotation order values for EulerRotationOrder in Unity QuaternionHelpers
kRotateOrderMapping = {
	0:'XYZ', 
	1:'YZX', 
	2:'ZXY', 
	3:'XZY', 
	4:'YXZ', 
	5:'ZYX'
}

def correctAssignments(expression, conflictDict, refTypeDict, referenceFieldDict, variableTypeDict, jointOrientVars):
	"""Correct assignments to integer and Vector3 variables and fields
	@param expression the contents of the expression node at this point in the translation process
	@param conflictDict a dictionary mapping Maya reference names to conflict-resolved alternatives
	@param refTypeDict a dictionary storing the Unity type for each reference in the list
	@param referenceFieldDict a dictionary mapping Maya attributes names to C# field types
	@param variableTypeDict a dictionary mapping variable names to their types
	@param jointOrientVars a dictionary mapping joint names to their prerotation Quaternion variables"""
	# create a reverse conflict dict
	originalNamesDict = dict((v,k) for k, v in conflictDict.iteritems())
	
	# locate all integer variables and fields
	integers = [conflictDict[v] for v in variableTypeDict if variableTypeDict[v] == 'int']
	integers += [conflictDict[v] for v in referenceFieldDict if referenceFieldDict[v] == 'int']
	
	# correct assignments on each line
	lines = expression.split('\n')
	expression = ''
	for line in lines:
		constituents = re.split('(?<![=<>])=(?!=)', line)
		# early out if there is no assignment
		if len(constituents) == 1:
			expression += '%s\n'%line
			continue
		
		# get the field or variable being assigned to
		var = constituents[0]
		# get the assignment value 
		val = constituents[1]
		
		# variables for storing reference.field pairs during substitution
		ref = ''
		field = ''
		
		# correct vectors in assignment value
		for rf in referenceFieldDict:
			ref = rf.split('.')[0]
			field = rf.split('.')[1]
			# repl is the value to substitute in place of rf so that e.g., object.translateY becomes object.localPosition.y
			repl = rf
			
			# early out if this is not a known reference or field, or if it is not a vector component
			if (not ref in refTypeDict or
				not refTypeDict[ref] in kAttributeDictionaries or
				not field in kAttributeDictionaries[refTypeDict[ref]] or 
				not '.' in kAttributeDictionaries[refTypeDict[ref]][field]):
				continue
			
			# get name as it will appear in the method body at this point
			ref = conflictDict[ref]
			
			# multiply position values by import settings scalar
			if re.match('translate', field) or (refTypeDict[originalNamesDict[ref]] == 'PointConstraint' and re.match('offset', field)):
				repl = 'oneOverImportScale*%s'%rf
				val = re.sub('(?<=\W)%s(?=\W)'%re.escape(rf), repl, val)
				# invert x-coordinate of position vectors
				if (kAttributeDictionaries[refTypeDict[originalNamesDict[ref]]][field][-1].lower() == 'x' or 
					kAttributeDictionaries[refTypeDict[originalNamesDict[ref]]][field][-1] == '0'):
					val = re.sub('(?<=\W)%s(?=\W)'%re.escape(repl), '-(%s)'%repl, val)
			
			# decompose and negate Euler rotations
			if ((refTypeDict[originalNamesDict[ref]] == 'Transform' and re.match('rotate', field)) or 
				(refTypeDict[originalNamesDict[ref]] == 'AimConstraint' and re.match('offset', field)) or 
				(refTypeDict[originalNamesDict[ref]] == 'OrientConstraint' and re.match('offset', field)) or
				(refTypeDict[originalNamesDict[ref]] == 'ExposeTransform' and re.match('eulerRotation', field))):
				# decompose rotation if not coming from an exposeTransform node
				if not refTypeDict[originalNamesDict[ref]] == 'ExposeTransform':
					repl = 'QuaternionHelpers.ToEulerAngles(%s.localRotation, EulerRotationOrder.%s).%s'%(ref, 
						kRotateOrderMapping[cmds.getAttr('%s.rotateOrder'%ref)],
						kAttributeDictionaries[refTypeDict[originalNamesDict[ref]]][field][-1])
					# negate yz rotation
					if not repl[-1].lower() == 'x': repl = '-(%s)'%repl
					# apply jointOrient transformation
					if cmds.nodeType(originalNamesDict[ref]) == 'joint':
						repl = re.sub('%s\.localRotation'%ref, 'Quaternion.Inverse(%s)*%s.localRotation'%(jointOrientVars[originalNamesDict[ref]],ref), repl)
				# replace syntax
				val = re.sub('(?<=\W)%s(?=\W)'%re.escape(rf), repl, val)
		
		# cast int assignments
		for v in integers:
			if not v == var.lstrip().rstrip(): continue
			val = ' (int)(%s);'%val.lstrip().rstrip()[:-1]
		
		# correct assignments to vector fields
		ref = var[0:var.find('.')].lstrip()
		field = var[var.find('.')+1:].rstrip()
		if ref in refTypeDict:
			# Vector3 values will have a . in their corresponding fields in Unity
			if (ref in originalNamesDict and
				originalNamesDict[ref] in refTypeDict and
				refTypeDict[originalNamesDict[ref]] in kAttributeDictionaries and
				field in kAttributeDictionaries[refTypeDict[originalNamesDict[ref]]] and 
				'.' in kAttributeDictionaries[refTypeDict[originalNamesDict[ref]]][field]):
				# divide position values by import settings scalar
				if re.match('translate', field) or (refTypeDict[originalNamesDict[ref]] == 'PointConstraint' and re.match('offset', field)):
					val = ' importScale*(%s);'%val.lstrip().rstrip()[:-1]
					# if it is an x-value, then negate it
					if (kAttributeDictionaries[refTypeDict[originalNamesDict[ref]]][field][-1].lower() == 'x' or
						kAttributeDictionaries[refTypeDict[originalNamesDict[ref]]][field][-1] == '0'):
						val = ' -(%s);'%val.lstrip()[:-1]
				# negate x rotations
				if (((refTypeDict[originalNamesDict[ref]] == 'Transform' and re.match('rotate', field)) or 
					(refTypeDict[originalNamesDict[ref]] == 'AimConstraint' and re.match('offset', field)) or 
					(refTypeDict[originalNamesDict[ref]] == 'OrientConstraint' and re.match('offset', field))) and 
					not (field[-1].lower()=='x' or field[-1]=='0')): # TODO: is this right?
					val = ' -(%s);'%val.lstrip().rstrip()[:-1]
				# build the new assignment syntax
				indentation = re.match('\s+', var)
				if not indentation: indentation = ''
				else: indentation = indentation.group(0)
				# determine which private field to use
				getVector3 = 'localPosition'
				if 'rotate' in var.lower(): getVector3 = 'localEulerAngles'
				elif 'scale' in var.lower(): getVector3 = 'localScale'
				# get the name of the Vector3 field
				setVector3 = kAttributeDictionaries[refTypeDict[originalNamesDict[ref]]][field]
				setVector3 = setVector3[:setVector3.find('.')]
				# fix scale/positision syntax
				if not 'rotate' in var.lower():
					var = '%s%s = %s.%s;\n%s%s.%s '%(indentation, getVector3, ref, setVector3, indentation, getVector3, kAttributeDictionaries[refTypeDict[originalNamesDict[ref]]][field][-1]);
					val = '%s\n%s%s.%s = %s;'%(val, indentation, ref, setVector3, getVector3)
				# fix rotation syntax
				else:
					rotateOrder = kRotateOrderMapping[cmds.getAttr('%s.rotateOrder'%ref)]
					var = '%s%s = QuaternionHelpers.ToEulerAngles(%s.localRotation, EulerRotationOrder.%s);\n%s%s.%s '%(indentation, getVector3, ref, rotateOrder, indentation, getVector3, kAttributeDictionaries[refTypeDict[ref]][field][-1]);
					if cmds.nodeType(originalNamesDict[ref]) == 'joint':
						var = re.sub('QuaternionHelpers\.ToEulerAngles\(%s\.localRotation'%ref,
							'QuaternionHelpers.ToEulerAngles(Quaternion.Inverse(%s)*%s.localRotation'%(jointOrientVars[originalNamesDict[ref]], ref), var)
					val = '%s\n%s%s.localRotation = QuaternionHelpers.FromEulerAngles(%s, EulerRotationOrder.%s);'%(val, indentation, ref, getVector3, rotateOrder)
					if cmds.nodeType(originalNamesDict[ref]) == 'joint': # TODO: This may not be totally bulletproof
						val = re.sub('localRotation = QuaternionHelpers\.FromEulerAngles', 'localRotation = %s*QuaternionHelpers.FromEulerAngles'%jointOrientVars[originalNamesDict[ref]], val)
		
		# clean up reciporical multiplication
		pattern = 'importScale\*\(oneOverImportScale\*[\w.]+\)'
		block = re.search(pattern, val)
		if block: val = re.sub(pattern, block.group(0)[32:-1], val)
		pattern = 'importScale\*\(-\(oneOverImportScale\*[\w.]+\)\)'
		block = re.search(pattern, val)
		if block: val = re.sub(pattern, '-%s'%block.group(0)[34:-2], val)
		
		# clean up double negation
		val = re.sub('\(\-\-\(', '((', val)
		val = re.sub('\-\-\(', '(', val)
		
		# TODO: clean up sequential transform field setting
				
		# rebuild the line using the new syntax
		line = '%s = %s'%(var.rstrip(), val.lstrip())
		expression += '%s\n'%line
	
	# return the modified result
	return expression.rstrip()

def correctReferenceFieldSyntax(expression, conflictDict, referenceTypeDict):
	"""Correct reference fields to match their corresponding Unity field name
	@param expression the contents of the expression node at this point in the translation process
	@param conflictDict a dictionary mapping Maya reference names to conflict-resolved alternatives
	@param referenceTypeDict a dictionary storing the Unity type for each reference in the list"""
	# create a reverse conflict dict
	originalNamesDict = dict((v,k) for k, v in conflictDict.iteritems())
	
	# find all potential reference fields in the code
	referenceFields = re.findall('\w+\.\w+', expression)
	for rf in referenceFields:
		reference = rf.split('.')[0]
		field = rf.split('.')[1]
		
		# skip float literals and unknown references such as e.g. Unity class names
		if not reference in originalNamesDict: continue
		reference = originalNamesDict[reference]
		if reference not in referenceTypeDict or (reference in kReservedKeywords and reference not in conflictDict) or re.match('\d', reference): continue
		
		# replace transform variables
		if referenceTypeDict[reference] == u'Transform':
			if field in kTransformAttributeAsUnityMember:
				expression = re.sub('(?<=\.)%s(?=\W)'%re.escape(field), kTransformAttributeAsUnityMember[field], expression)
		# replace expose transform variables
		elif referenceTypeDict[reference] == u'ExposeTransform':
			if field in kExposeTransformAttributeAsUnityMember:
				expression = re.sub('(?<=\.)%s(?=\W)'%re.escape(field), kExposeTransformAttributeAsUnityMember[field], expression)
		# fix constraint variables and assignments
		elif (referenceTypeDict[reference] == u'AimConstraint' or 
			referenceTypeDict[reference] == u'OrientConstraint' or 
			referenceTypeDict[reference] == u'PointConstraint'):
			weightAliasList = mel.eval('%s%s -q -wal %s'%(referenceTypeDict[reference][0].lower(), referenceTypeDict[reference][1:], reference))
			if field in weightAliasList:
				expression = re.sub('(?<=\.)%s(?=\W)'%re.escape(field), u'targets[%i].weight'%ampy.indexOf(field, weightAliasList), expression)
		elif (referenceTypeDict[reference] == u'BlendShape'):
			aliasList = cmds.aliasAttr(reference, q=True)
			if field in aliasList: expression = re.sub('\.%s\W'%re.escape(field), '["%s"].weight'%field, expression) # TODO: not the most ideal option, but fine for now
	
	return expression

def divToMult(division, expression):
	"""Return copy of expression with division specified in MatchObject converted to multiplication
	@param division a MatchObject corresponding to a division operation in expression
	@param expression the contents of the expression node at this point in the translation process
	"""
	return expression[0:division.start(0)]+'* %s'%(eval('1.0%s'%expression[division.start(0):division.end(0)]))+expression[division.end(0):]

def consolidateLiteralBlocks(expression, conflictDict, referenceFieldDict, variableTypeDict):
	"""Conlidate blocks of literal expressions
	@param expression the contents of the expression node at this point in the translation process
	@param conflictDict a dictionary mapping Maya reference names to conflict-resolved alternatives
	@param referenceFieldDict a dictionary mapping Maya attributes names to C# field types
	@param variableTypeDict a dictionary mapping variable names to their types"""
	# create a reverse conflict dict
	originalNamesDict = dict((v,k) for k, v in conflictDict.iteritems())
	
	# convert all division by float into multiplication by inverse
	while len(re.findall('/\s\d+\.\d+', expression)) > 0:
		division = re.search('/\s\d+\.\d+', expression)
		expression = divToMult(division, expression)
	
	# try to convert division by int into multiplication by float inverse if numerator is a float
	skip = 0
	while len(re.findall('/[\s\d]+', expression)) > skip:
		division = list(re.finditer('/[\s\d]+', expression))[skip]
		previousTerm = u'%s'%(re.search('[\d.\w]+', expression[0:division.start(0)][::-1]).group(0)[::-1])
		# previousTerm is an int literal
		if previousTerm.isnumeric(): skip +=1
		# previousTerm is something else
		else:
			# see if previousTerm is a float literal
			try:
				float (previousTerm)
				expression = divToMult(division, expression)
			# previousTerm is a variable or reference field
			except:
				var = '$%s'%previousTerm
				prevRefField = '%s.%s'%(originalNamesDict[re.search('.*?(?=\.)', previousTerm).group(0)], previousTerm[previousTerm.rfind('.')+1:])
				# previousTerm is a variable
				if var in originalNamesDict and originalNamesDict[var] in variableTypeDict:
					if not variableTypeDict[originalNamesDict[var]] == 'float': skip += 1
					else: expression = divToMult(division, expression)
				# previousTerm is a reference field
				elif prevRefField in referenceFieldDict:
					if not referenceFieldDict[prevRefField] == 'float': skip += 1
					else: expression = divToMult(division, expression)
				# unknown
				else: skip += 1
	
	# condense parenthetical blocks of literal expressions
	while len(re.findall('\([\s+\-/*\d.]+\)', expression)) > 0:
		block = re.search('\([\s+\-/*\d.]+\)', expression)
		expression = expression[0:block.start(0)]+'%s'%(eval(expression[block.start(0):block.end(0)]))+expression[block.end(0):]
	
	# condense remaining literal expressions
	skip = 0
	while len(re.findall('(?<!\w)[ */\d.]+(?!\w)', expression)) > skip:
		block = list(re.finditer('(?<!\w)[ */\d.]+(?!\w)', expression))[skip]
		injection = '1.0*'
		if (re.search('[*/]', block.group(0)) and re.search('\d', block.group(0)) and 
			(re.search('[*/]', block.group(0)).start(0) < re.search('\d', block.group(0)).start(0))):
			injection = '1.0'
		evaluateIt = '%s%s'%(injection, expression[block.start(0):block.end(0)])
		if len(re.split('[*/]', evaluateIt)) < 3 or not re.search('\d', block.group(0)): skip += 1
		else:
			finalDigit = len(evaluateIt) - re.search('[\d\w]', evaluateIt[::-1]).start(0) - 1
			finalOp = len(evaluateIt) - re.search('[*/]', evaluateIt[::-1]).start(0) - 1
			if finalDigit > finalOp:
				expression = expression[0:block.start(0)]+' %s'%eval(evaluateIt)+expression[block.end(0):]
			else:
				expression = expression[0:block.start(0)]+' %s %s'%(eval(evaluateIt[0:finalOp-1]), evaluateIt[finalOp])+expression[block.end(0):]
				skip += 1
	skip = 0
	while len(re.findall('(?<![\w])[ +\-\d.]+(?!\w)', expression)) > skip:
		block = list(re.finditer('(?<!\w)[ +\-\d.]+(?![\w])', expression))[skip]
		injection = '0.0+'
		if (re.search('[+\-]', block.group(0)) and re.search('\d', block.group(0)) and 
			(re.search('[+\-]', block.group(0)).start(0) < re.search('\d', block.group(0)).start(0))):
			injection = '0.0'
		evaluateIt = '%s%s'%(injection, expression[block.start(0):block.end(0)])
		if len(re.split('[+\-]', evaluateIt)) < 3 or not re.search('\d', block.group(0)): skip += 1
		else:
			finalDigit = len(evaluateIt) - re.search('[\d\w]', evaluateIt[::-1]).start(0) - 1
			finalOp = len(evaluateIt) - re.search('[+\-]', evaluateIt[::-1]).start(0) - 1
			if finalDigit > finalOp:
				if (expression[block.end(0)] == '*' or expression[block.end(0)] == '/'):
					finalNumber = re.search('[\.\d\s]+$', evaluateIt)
					expression = expression[0:block.start(0)]+' %s %s%s'%(eval(evaluateIt[0:finalNumber.start(0)-1]), evaluateIt[finalOp], evaluateIt[finalNumber.start(0):])+expression[block.end(0):]
					skip += 1
				else:
					expression = expression[0:block.start(0)]+' %s'%eval(evaluateIt)+expression[block.end(0):]
			else:
				expression = expression[0:block.start(0)]+' %s %s'%(eval(evaluateIt[0:finalOp-1]), evaluateIt[finalOp])+expression[block.end(0):]
				skip += 1
	
	# clean up spacing
	matches = list(re.finditer('\(\s\d', expression))
	for match in matches: expression = re.sub(re.escape(match.group(0)), '(%s'%match.group(0)[2], expression)
	matches = list(re.finditer('\d\s\)', expression))
	for match in matches: expression = re.sub(re.escape(match.group(0)), '%s)'%match.group(0)[0], expression)
	matches = list(re.finditer('\d [+\-*/]\(', expression))
	for match in matches: expression = re.sub(re.escape(match.group(0)), '%s ('%match.group(0)[:-1], expression)
	
	# return modified expression
	return expression

def correctFloatLiteralSyntax(expression):
	"""Correct float literal syntax for C# by appending f suffix
	@param expression the contents of the expression node at this point in the translation process"""
	literals = re.findall('\d+\.\d+', expression)
	for literal in literals:
		expression = re.sub('(?<!\w)%s(?!\w)'%re.escape(literal), '%sf'%literal, expression)
	literals = re.findall('\d+\.0f', expression)
	for literal in literals:
		expression = re.sub('(?<!\w)%s(?!\w)'%re.escape(literal), '%sf'%literal[:-3], expression)
	return expression